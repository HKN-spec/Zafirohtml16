pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()

        maven { url = uri("https://maven.aliyun.com/repository/public") }
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        maven { url = uri("https://maven.aliyun.com/repository/jcenter") }
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        maven { url = uri("https://jitpack.io") }

        maven { url = uri("https://chaquo.com/maven") }
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()

        maven { url = uri("https://maven.aliyun.com/repository/public") }
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        maven { url = uri("https://maven.aliyun.com/repository/jcenter") }
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        maven { url = uri("https://jitpack.io") }

        maven { url = uri("https://chaquo.com/maven") }
    }
}
rootProject.name = "Zafiro"
include(":app")
include(":xposed-api")
include(":xposed-runtime")
include(":ui-kit")
include(":remote-view")
include(":store")
include(":agent-runtime")
include(":accessibility")

// Evrim organizması: bağımsız (Android'siz) çekirdek. Ajan araçları, CI rahmi,
// genom/soy ağacı ve vicdan burada yaşar; platform yetenekleri portlardan girer.
include(":evolution")

// 本地配置读取口：给 app 模块以外的模块按需依赖，见 xsettings/XSettings.kt 的「懒」规则。
include(":xsettings")

// Business 层：契约（api）与实现（agent）分离，业务方只依赖 api。
include(":business:api")
// 屏幕契约。纯 JVM，只有签名。实现以后再注册到 ServiceRegistry。
include(":business:screen")
include(":business:agent")
include(":business:files")
include(":business:notification")
include(":business:application")
include(":business:permission")
// 遥测实现。只有 :app 依赖它。
include(":business:remote")

// Vendored libraries (see libs/README.md)
include(":libs:logging")
include(":libs:okia")
include(":libs:shizuku")
include(":libs:libterm-core")
project(":libs:libterm-core").projectDir = file("libs/libterm/libterm-core")
include(":libs:libterm-runtime")
project(":libs:libterm-runtime").projectDir = file("libs/libterm/libterm-runtime")
include(":libs:libterm-backend-libsu")
project(":libs:libterm-backend-libsu").projectDir = file("libs/libterm/libterm-backend-libsu")
include(":libs:libterm-backend-shizuku")
project(":libs:libterm-backend-shizuku").projectDir = file("libs/libterm/libterm-backend-shizuku")
include(":libs:libterm-backend-ssh")
project(":libs:libterm-backend-ssh").projectDir = file("libs/libterm/libterm-backend-ssh")
