package com.niki914.uikit.infra.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

@Composable
fun MaterialTintLiquidButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    containerColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.onPrimary,
    leadingIcon: (@Composable () -> Unit)? = null,
) {
    val backdrop = rememberLayerBackdrop()
    val disabledContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.45f)
    val disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)

    Box(
        modifier = modifier
            .fillMaxWidth()
            // 槽位比胶囊高 8dp，与 TintLiquidButton 一致：给按下的液态形变留量
            .heightIn(min = 64.dp),
        contentAlignment = Alignment.Center,
    ) {
        LiquidButton(
            onClick = if (enabled) onClick else { -> },
            backdrop = backdrop,
            modifier = Modifier.fillMaxWidth(),
            isInteractive = enabled,
            tint = if (enabled) containerColor else disabledContainerColor,
            surfaceColor = if (enabled) liquidButtonSurfaceColor(containerColor) else Color.Transparent,
        ) {
            val resolvedContentColor = if (enabled) contentColor else disabledContentColor
            CompositionLocalProvider(LocalContentColor provides resolvedContentColor) {
                if (leadingIcon == null) {
                    Text(
                        text = text,
                        style = MaterialTheme.typography.titleMedium,
                        color = resolvedContentColor,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        leadingIcon()
                        Text(
                            text = text,
                            style = MaterialTheme.typography.titleMedium,
                            color = resolvedContentColor,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}
